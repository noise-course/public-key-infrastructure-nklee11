"""
Local HTTPS server using a self-signed certificate.
"""

import http.server
import ssl
from pathlib import Path
import os

web_server_dir = Path(
    "~/Desktop/UChicago/UChicago Fourth Year/"
    "[CMSC 20350] Security, Privacy, and Consumer Protection/Lab 1/Website"
).expanduser()

certificates_path = Path(
    "~/Desktop/UChicago/UChicago Fourth Year/"
    "[CMSC 20350] Security, Privacy, and Consumer Protection/certificates"
).expanduser()

key = certificates_path / "server.key"
crt = certificates_path / "server.crt"

os.chdir(web_server_dir)

HttpHandler = http.server.SimpleHTTPRequestHandler
https_server = http.server.HTTPServer(('localhost', 8443), HttpHandler)

ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
ssl_context.load_cert_chain(certfile=str(crt), keyfile=str(key))

https_server.socket = ssl_context.wrap_socket(
    https_server.socket, server_side=True)

https_server.serve_forever()
